# DoxSoft
Лучший софт для докс

# Установка:
1. termux-setup-storage
2. pkg install python -y
3. pkg install git -y
4. git clone https://github.com/anfisovDoxer/DoxSoft
5. cd DoxSoft
6. pip install -r requirments.txt
7. python crypted.py
